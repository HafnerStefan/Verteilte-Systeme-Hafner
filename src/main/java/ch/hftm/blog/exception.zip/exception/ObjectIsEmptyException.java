package ch.hftm.blog.exception;

public class ObjectIsEmptyException extends RuntimeException{
	public ObjectIsEmptyException(String message) {
		super(message);
	}
}
