package ch.hftm.blog.boundry;

public class ValidationGroups {
    public interface Create {
    }

    public interface Update {
    }
}
