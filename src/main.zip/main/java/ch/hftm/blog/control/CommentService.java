package ch.hftm.blog.control;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import ch.hftm.blog.dto.CommentBaseDTO;
import ch.hftm.blog.dto.CommentWithBlogContextDTO;
import ch.hftm.blog.dto.CommentWithBlogTitleDTO;
import ch.hftm.blog.dto.mapper.CommentMapper;
import ch.hftm.blog.entity.Blog;
import ch.hftm.blog.entity.Comment;
import ch.hftm.blog.entity.User;
import ch.hftm.blog.exception.ObjectNotFoundException;
import ch.hftm.blog.repository.BlogRepository;
import ch.hftm.blog.repository.CommentRepository;
import ch.hftm.blog.repository.UserRepository;


import io.quarkus.logging.Log;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@Dependent
public class CommentService {
	@Inject
	CommentRepository commentRepository;
	@Inject
	BlogRepository blogRepository;
	@Inject
	UserRepository userRepository;

	public List<CommentBaseDTO> getComments() {
		var comments = commentRepository.listAll();
		Log.info("Returning " + comments.size() + " comments");
		return comments.stream().map(CommentMapper::toCommentBaseDTO).collect(Collectors.toList());
	}

	public CommentBaseDTO getCommentDTOById(Long commentId) {
		Comment comment = getCommentById(commentId);
		return CommentMapper.toCommentBaseDTO(comment);
	}

	public Comment getCommentById(Long commentId) {
		Comment comment = commentRepository.findById(commentId);
		if (comment != null) {
			return comment;
		} else {
			throw new ObjectNotFoundException("Comment with id " + commentId + " not found");
		}
	}

	public List<CommentWithBlogTitleDTO> getCommentsWithBlogTitleByUserId(Long userId) {
		List<Comment> comments = commentRepository.findByUserId(userId);
		if (comments != null) {
			return comments.stream().map(CommentMapper::toCommentWithBlogTitleDTO).collect(Collectors.toList());
		} else {
			throw new ObjectNotFoundException("No comments found for user with id " + userId);
		}
	}

	public CommentWithBlogContextDTO getCommentWithBlogContextById(Long commentId,int previousCommentSize, int nextCommentSize) {
		Comment comment = getCommentById(commentId);
		List<Comment> previousComments = commentRepository.findPreviousComments(comment.getBlog().getId(), comment.getCreatedAt(), previousCommentSize);
		List<Comment> nextComments = commentRepository.findNextComments(comment.getBlog().getId(), comment.getCreatedAt(), nextCommentSize);
		return CommentMapper.toCommentWithBlogContextDTO(comment, previousComments, nextComments);
	}



	public List<CommentBaseDTO> getCommentsByBlogId(Long blogId) {
		List<Comment> comments = commentRepository.findByBlogId(blogId);
		if (comments != null && !comments.isEmpty()) {
			return comments.stream().map(CommentMapper::toCommentBaseDTO).collect(Collectors.toList());
		} else {
			throw new ObjectNotFoundException("No comments found for blog with id " + blogId);
		}
	}

	public List<CommentBaseDTO> getCommentsByUserId(Long userId) {
		List<Comment> comments = commentRepository.findByUserId(userId);
		if (comments != null && !comments.isEmpty()) {
			return comments.stream().map(CommentMapper::toCommentBaseDTO).collect(Collectors.toList());
		} else {
			throw new ObjectNotFoundException("No comments found for user with id " + userId);
		}
	}


	@Transactional
	public CommentBaseDTO addComment(CommentBaseDTO commentBaseDTO) {
		Comment comment = CommentMapper.toComment(commentBaseDTO);
		Blog blog = blogRepository.findById(commentBaseDTO.getBlogId());
		User user = userRepository.findById(commentBaseDTO.getUserId());
		comment.setBlog(blog);
		comment.setUser(user);
		comment.setCreatedAt(LocalDateTime.now());
		Log.info("Adding Comment by User " + comment.getUser().getName());
		commentRepository.persist(comment);
		return CommentMapper.toCommentBaseDTO(comment);
	}

	@Transactional
	public void deleteComment(Long commentId) {
		Comment comment = commentRepository.findById(commentId);
		if (comment == null) {
			throw new ObjectNotFoundException("Comment with id " + comment + " not found");
		}
		Blog blog = comment.getBlog();
		User user = comment.getUser();

		if (blog != null){
			blog.getComments().remove(comment);
		}
		if (user != null){
			user.getComments().remove(comment);
		}
		commentRepository.delete(comment);

		if (blog != null){
			blogRepository.persistAndFlush(blog);
		}
		if (user != null){
			userRepository.persistAndFlush(user);
		}
		Log.info("Deleting Comment by User " + comment.getUser().getName());
	}




}